# FollowerBot
Follower bot for Instagram:

After you run the program, enter your instagram username and get free Instagram followers. If you run it during 12 hours, you'll get 400 followers! No need to enter your password to the system. PS: You have to public profile to get free followers. 

# LikeBot
Liker bot for Instagram:

After you run the program, enter your instagram post URL and get free Instagram likes. If you run it during 1 day, you'll get 1570 likes! No need to enter your password to the system. PS: You have to public profile to get free likes.

# Get Credit

I wrote a bot program for websites that the more credits you earn, the more followers and likes you can gain. The bot helps you earn credits by going to the relevant website and watching videos in the background. In order to convert these credits into followers or likes, you need to go to the website manually from your browser and make the definitions.

# Remarks

When you get expiration error on get_instagram_followers.py or get_instagram_likes.py programs, please change your Instagram username and start the bot again.

Although you change your username and still get expiration error, please try VPN and start the bot again. For example: Hotspot Shield Free VPN program.
